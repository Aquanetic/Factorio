data:extend({
{
	type = "item",
	name = "w93-hardened-inserter",

	icon = "__scattergun_turret__/graphics/icons/hardened-inserter.png",

	icon_size = 64,
	icon_mipmaps = 4,
	flags = {},

	subgroup = "inserter",
	order = "c[long-handed-inserter]-a[w93-hardened-inserter]",

	place_result = "w93-hardened-inserter",
	stack_size = 50

}})