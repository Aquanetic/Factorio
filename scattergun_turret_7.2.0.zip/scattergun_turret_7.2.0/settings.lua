data:extend({
{
	type = "bool-setting",
	name = "enable-radars",
	setting_type = "startup",
	default_value = true,
	order = "aa"
},
{
	type = "bool-setting",
	name = "enable-hardened-inserter",
	setting_type = "startup",
	default_value = true,
	order = "ab"
},
{
	type = "bool-setting",
	name = "enable-extra-ammo",
	setting_type = "startup",
	default_value = true,
	order = "ac"
},
{
	type = "bool-setting",
	name = "cannon-ammo-range-disable",
	setting_type = "startup",
	default_value = true,
	order = "ad"
},
{
	type = "bool-setting",
	name = "enable-pretargeting",
	setting_type = "startup",
	default_value = true,
	order = "ae"
}})