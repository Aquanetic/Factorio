# PlannerCore

Core mod for the planner series of mods ([Outpost Planner](https://github.com/Ben-Ramchandani/OutpostPlanner)).

This mod contains most of the code, allowing the mods to call each other without all of them being installed.

[Link to Factorio mod website](https://mods.factorio.com/mods/bob809/PlannerCore)

Please submit bug reports to the issues page of the mod you're using when the crash occurs instead of here.

## Changelog

0.2.3

* Fix script event crash in Factorio version >= 0.18.27

0.2.2

* Update for 0.18

0.2.1

* OutpostPlanner now correctly raises `on_built_entity` event.

0.2.0

* Update for 0.17

0.1.2

* Minor updates from OutpostPlanner 1.0.3.

0.1.1

* Fixed bug with other entities only being placed when miners are.

0.1.0

* First public version (Factorio version 0.16.1).
