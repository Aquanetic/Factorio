local global_data = {}

function global_data.init()
  global.players = {}
end

return global_data