data:extend{
  {
    type = "bool-setting",
    name = "bpt-show-buttons",
    setting_type = "runtime-per-user",
    default_value = true
  },
  {
    type = "bool-setting",
    name = "bpt-consider-tiles-for-quick-grid",
    setting_type = "runtime-per-user",
    default_value = true
  }
}
