data:extend(
{
  	{
		type = "item",
		name = "bucket-wheel-excavator",
		icon = "__BigDrills__/graphics/icons/bucketW-mkI.png",
        icon_size = 32,
		flags = {},
		subgroup = "extraction-machine",
		order = "a[items]-b[electric-mining-drill]",
		place_result = "bucketw",
		stack_size = 1
	},
  	{
		type = "item",
		name = "bucket-wheel-excavator-mk2",
        icon_size = 32,
		icon = "__BigDrills__/graphics/icons/bucketW-mkII.png",
		flags = {},
		subgroup = "extraction-machine",
		order = "a[items]-b[electric-mining-drill]",
		place_result = "bucketw-mk2",
		stack_size = 1
	},
  	{
		type = "item",
		name = "bucket-wheel-excavator-mk3",
        icon_size = 32,
		icon = "__BigDrills__/graphics/icons/bucketW-mkIII.png",
		flags = {},
		subgroup = "extraction-machine",
		order = "a[items]-b[electric-mining-drill]",
		place_result = "bucketw-mk3",
		stack_size = 1
	}
})
