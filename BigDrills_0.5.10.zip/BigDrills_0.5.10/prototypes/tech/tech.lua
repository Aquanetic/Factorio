-- RESEARCH
local MK1, MK2, MK3
if mods["bobplates"] and not mods["IndustrialRevolution"] then -- Only use bobplates recipes, when IndustrialRevolution is not active
    MK1 = {"electric-engine", "logistics-2"}
    MK2 = {"logistics-2", "bucket-wheel-excavator", "advanced-material-processing-2", "titanium-processing"}
    MK3 = {"logistics-3", "bucket-wheel-excavator-mk2", "nitinol-processing", "tungsten-alloy-processing"}
elseif mods["IndustrialRevolution"] then
    MK1 = {"electric-engine", "logistics-2"}
    MK2 = {"logistics-2", "bucket-wheel-excavator", "chemical-science-pack"}
    MK3 = {"logistics-3", "bucket-wheel-excavator-mk2"}
else
    MK1 = {"electric-engine", "logistics-2"}
    MK2 = {"logistics-2", "bucket-wheel-excavator", "advanced-material-processing-2"}
    MK3 = {"logistics-3", "bucket-wheel-excavator-mk2"}
end


data:extend(
{
  {
    type = "technology",
    name = "bucket-wheel-excavator",
    localised_name = {"technology-name.bucket-wheel-excavator"},
    localised_description = {"technology-description.bw-mk-1"},
    icon = "__BigDrills__/graphics/technology/BigWheelTech-MKI.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "bucket-wheel-excavator"
      },
    },
    prerequisites = MK1,
    unit = {
      count = 80,
      ingredients = {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2}
      },
      time = 35
    },
    order = "c-g-b-z",
  },
  {
    type = "technology",
    name = "bucket-wheel-excavator-mk2",
    localised_name = {"technology-name.bucket-wheel-excavator-mk2"},
    localised_description = {"technology-description.bw-mk-2"},
    icon = "__BigDrills__/graphics/technology/BigWheelTech-MKII.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "bucket-wheel-excavator-mk2"
      },
    },
    prerequisites = MK2,
    unit = {
      count = 60,
      ingredients = {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
		{"chemical-science-pack", 1}
      },
      time = 60
    },
    order = "c-g-b-z",
  },
  {
    type = "technology",
    name = "bucket-wheel-excavator-mk3",
    localised_name = {"technology-name.bucket-wheel-excavator-mk3"},
    localised_description = {"technology-description.bw-mk-3"},
    icon = "__BigDrills__/graphics/technology/BigWheelTech-MKIII.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "bucket-wheel-excavator-mk3"
      },
    },
    prerequisites = MK3,
    unit = {
      count = 100,
      ingredients = {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
		{"chemical-science-pack", 2},
		{"production-science-pack", 1}
      },
      time = 70
    },
    order = "c-g-b-z",
  }
})
