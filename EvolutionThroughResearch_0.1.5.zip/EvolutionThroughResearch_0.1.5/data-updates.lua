if data.raw["tips-and-tricks-item"]["introduction"] and data.raw["tips-and-tricks-item"]["evolution-through-research"] then
    data.raw["tips-and-tricks-item"]["evolution-through-research"].dependencies = {"introduction"}
end