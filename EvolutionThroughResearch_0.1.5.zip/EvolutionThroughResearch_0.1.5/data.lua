data:extend(
{
  {
    type = "tips-and-tricks-item",
    name = "evolution-through-research",
    category = "game-interaction",
    order = "zz[evolution-through-research]",
    image = "__EvolutionThroughResearch__/graphics/tips-and-tricks/evolution.png"
  },
})
