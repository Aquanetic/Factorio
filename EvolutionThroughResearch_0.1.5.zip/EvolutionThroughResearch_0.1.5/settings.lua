data:extend(
{
    {
        type = "int-setting",
        name = "evolution-through-research-frequency",
        setting_type = "startup",
        default_value = 1,
        order = "a",
    },
}
)


