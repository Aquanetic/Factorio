data:extend(
{
  {
    type = "item-group",
    name = "MoreSciencePacks-for1_1",
    order = "z",
    inventory_order = "z",
    icon = "__MoreSciencePacks-for1_1__/graphics/efficiency-generic.png",
	icon_size = 128,
  },
}
)