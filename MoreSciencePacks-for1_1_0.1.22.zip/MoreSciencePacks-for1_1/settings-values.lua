
standard = {"Not Enabled", "Enabled"}
difficulty = {"Easiest", "Very Easy", "Easy", "Standard", "Hard", "Harder", "Very Hard", "Hardest"}

--[[
--wormmus example. will change settings to this variation later...
range_player_inventorysize = {"Not Enabled", "100", "150", "200", "250"}
range_player_longreach = {"Not Enabled", "Short", "Medium", "Far", "Too Far", "Everything"}

range_tweaks_stacksize = {"Not Enabled", "Suggested", "2x", "5x", "10x"}

range_warfare_magazinecapacity = {"Not Enabled", "25", "50", "100", "250", "500", "1000", "2500", "5000", "10000"}
range_warfare_weaponcooldown = {"Not Enabled", "Moderate", "Fast"}
--]]
